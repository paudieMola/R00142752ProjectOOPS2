package view;

import javafx.scene.control.Button;

public class EditButton extends Button {
	public EditButton() {
		super("Edit");
	}

}
