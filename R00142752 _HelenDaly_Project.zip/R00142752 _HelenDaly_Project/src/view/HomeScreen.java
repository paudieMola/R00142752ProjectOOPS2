
package view;
import java.io.Serializable;
import exception.ButtonException;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

public class HomeScreen extends BorderPane implements Serializable {
	//I wanted this to be the structure of all subsequent screens. A blank border Pane with buttons down the side. 
	HBox header = new HBox();
	VBox sidePanel = new VBox();
	ScreenTemplate screen;
	
	public HomeScreen() {
		try {
			buildHomeScreen();//kick off the method
		} catch (ButtonException e) {
			e.printStackTrace();
		}
	}

	private void buildHomeScreen() throws ButtonException {
		header.setPadding(new Insets(15, 12, 15, 12));//set up panels in borderPane as basis for all other screens
		header.setSpacing(10);
		sidePanel.setPadding(new Insets(15, 12, 15, 12));
		sidePanel.setSpacing(10);
		Text headerText = new Text ("Gentle Dental");
		this.setBackground(null);
		ImageView tooth = new ImageView(new Image("Main/tooth.jpg"));
		tooth.setFitHeight(30);
		tooth.setFitWidth(30);
		header.getChildren().addAll(tooth,headerText);
		this.setTop(header);
		header.setAlignment(Pos.CENTER);
		this.setLeft(sidePanel);
		
		MyButton homeButton = new MyButton("Home");//button for changing to middle display home screen
		homeButton.setOnAction(e -> {
			FilledHomeScreen fhomeScreen = new FilledHomeScreen();
			this.setCenter(fhomeScreen);
		});
		
		MyButton patientsButton = new MyButton("Patients");//button to change middle display to display patients
		patientsButton.setOnAction(e -> {
			PatientsScreen patScreen = new PatientsScreen();
			this.setCenter(patScreen);
		});
		
		MyButton proceduresButton = new MyButton("Procedures");//button to change middle display to procedures scene
		proceduresButton.setOnAction(e -> {
			ProceduresScreen procScreen = new ProceduresScreen();
			this.setCenter(procScreen);
		});
		
		MyButton calendarButton = new MyButton("Appointments");//button to change middle to a calendar displaying appointments
		calendarButton.setOnAction(e -> {
			CalendarScreen calScreen = new CalendarScreen();
			this.setCenter(calScreen);
		});
		sidePanel.getChildren().addAll(homeButton, patientsButton, proceduresButton, calendarButton);//add buttons to side of borderPane
		return ;
	}

	//getters and setters if i need them later
	public HBox getHeader() {return header;}
	public void setHeader(HBox header) {this.header = header;}
	public VBox getSidePanel() {return sidePanel;}
	public void setSidePanel(VBox sidePanel) {this.sidePanel = sidePanel;}
	
}