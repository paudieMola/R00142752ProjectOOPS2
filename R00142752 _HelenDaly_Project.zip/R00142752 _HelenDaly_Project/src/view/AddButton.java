package view;

import javafx.scene.control.Button;

public class AddButton extends Button{
	
	public AddButton() {//just a button with add on it.
		super("Add");
	}

}
