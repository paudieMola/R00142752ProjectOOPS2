package view;

import java.io.Serializable;

import javafx.scene.layout.GridPane;

public class FilledHomeScreen extends GridPane implements Serializable {

	public FilledHomeScreen () {//was going to put something in here to fill the blue planet
		super();
	}
}
