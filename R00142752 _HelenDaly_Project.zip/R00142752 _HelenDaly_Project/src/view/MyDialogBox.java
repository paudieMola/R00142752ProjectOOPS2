package view;

public class MyDialogBox {//I'll use this later

}
