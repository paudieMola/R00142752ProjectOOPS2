package view;

import classes.Patient;
import javafx.scene.layout.GridPane;

public class PatientDetailScreen extends GridPane{
	//to display all patient details
	public PatientDetailScreen(Patient patient) {
		super();
		}

}
