package view;

import javafx.scene.layout.StackPane;

public class CalendarScreen extends StackPane{
	public CalendarScreen() {
		//create a calendar with appointments
	}
}
