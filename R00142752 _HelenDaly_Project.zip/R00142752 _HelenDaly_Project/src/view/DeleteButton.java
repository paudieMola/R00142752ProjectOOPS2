package view;

import javafx.scene.control.Button;

public class DeleteButton extends Button {
	public DeleteButton() {
		super("Delete");
	}

}
