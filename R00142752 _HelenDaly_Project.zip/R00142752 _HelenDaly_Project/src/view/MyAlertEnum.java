package view;
//
public enum MyAlertEnum {//enums to create a type of alert
	Show,
	Timed
}
