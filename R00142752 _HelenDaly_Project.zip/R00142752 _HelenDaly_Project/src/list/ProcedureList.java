package list;

import java.io.Serializable;

public class ProcedureList extends ObjectList implements Serializable {

	public ProcedureList() {
		super();
	}
}
