package list;

import java.io.Serializable;

import classes.Payment;

public class PaymentList extends ObjectList implements Serializable {
	//list of payment objects
	public PaymentList() {
		super();
	}

}
