package list;

import java.io.Serializable;

import classes.Patient;

public class PatientList extends ObjectList implements Serializable {
	//list of Patients
	public PatientList() {
		super();
	}
	
	//public void addPatient(Patient patient) {
		//this.add(patient);
	//}

}
