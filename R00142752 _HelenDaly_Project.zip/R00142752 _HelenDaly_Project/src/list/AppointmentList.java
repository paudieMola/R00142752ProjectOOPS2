package list;

import java.io.Serializable;

public class AppointmentList extends ObjectList implements Serializable {

	public AppointmentList() {
		super();
	}

}
