package list;

import java.io.Serializable;
import classes.Invoice;

public class InvoiceList extends ObjectList implements Serializable {
	//list to hold invoices
	public InvoiceList() {
		super();
	}
	
}
