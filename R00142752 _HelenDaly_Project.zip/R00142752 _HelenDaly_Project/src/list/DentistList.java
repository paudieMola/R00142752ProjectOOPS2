package list;

import java.io.Serializable;
import classes.Dentist;

public class DentistList extends ObjectList implements Serializable {
	
	public DentistList() {
		super();
	}

}
