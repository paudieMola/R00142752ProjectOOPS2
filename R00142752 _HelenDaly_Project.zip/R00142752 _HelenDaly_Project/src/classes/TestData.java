package classes;

public class TestData {//I can create test data in here but I've included it in controller for now

}
