package storage;
//
public class DatabaseStorage implements StorageIntface{

	
	@Override
	public boolean save(Object o) {
		//to save to database
		return false;
	}
	@Override
	public Object load() {
		// to load from database
		return null;
	};
}
